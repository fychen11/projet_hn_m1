var wms_layers = [];

var format_district_yindu_0 = new ol.format.GeoJSON();
var features_district_yindu_0 = format_district_yindu_0.readFeatures(json_district_yindu_0, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_district_yindu_0 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_district_yindu_0.addFeatures(features_district_yindu_0);
var lyr_district_yindu_0 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_district_yindu_0, 
                style: style_district_yindu_0,
                popuplayertitle: "district_yindu",
                interactive: true,
                    title: '<img src="styles/legend/district_yindu_0.png" /> district_yindu'
                });
var format_data_os_1 = new ol.format.GeoJSON();
var features_data_os_1 = format_data_os_1.readFeatures(json_data_os_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_data_os_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_data_os_1.addFeatures(features_data_os_1);
var lyr_data_os_1 = new ol.layer.Heatmap({
                declutter: false,
                source:jsonSource_data_os_1, 
                radius: 15 * 2,
                gradient: ['#fff5f0', '#fee0d2', '#fcbba1', '#fc9272', '#fb6a4a', '#ef3b2c', '#cb181d', '#a50f15', '#67000d'],
                blur: 15,
                shadow: 250,
    weight: function(feature){
        var weightField = 'anim_tot';
        var featureWeight = feature.get(weightField);
        var maxWeight = 104;
        var calibratedWeight = featureWeight/maxWeight;
        return calibratedWeight;
    },
                title: 'data_os'
            });
var format_sites_2 = new ol.format.GeoJSON();
var features_sites_2 = format_sites_2.readFeatures(json_sites_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_sites_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_sites_2.addFeatures(features_sites_2);
var lyr_sites_2 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_sites_2, 
                style: style_sites_2,
                popuplayertitle: "sites",
                interactive: true,
                    title: '<img src="styles/legend/sites_2.png" /> sites'
                });

lyr_district_yindu_0.setVisible(true);lyr_data_os_1.setVisible(true);lyr_sites_2.setVisible(true);
var layersList = [lyr_district_yindu_0,lyr_data_os_1,lyr_sites_2];
lyr_district_yindu_0.set('fieldAliases', {'NAME': 'NAME', 'PYNAME': 'PYNAME', 'ADMINCODE': 'ADMINCODE', 'KIND': 'KIND', });
lyr_sites_2.set('fieldAliases', {'id': 'id', 'nom': 'nom', });
lyr_district_yindu_0.set('fieldImages', {'NAME': 'TextEdit', 'PYNAME': 'TextEdit', 'ADMINCODE': 'TextEdit', 'KIND': 'TextEdit', });
lyr_sites_2.set('fieldImages', {'id': 'TextEdit', 'nom': 'TextEdit', });
lyr_district_yindu_0.set('fieldLabels', {'NAME': 'no label', 'PYNAME': 'no label', 'ADMINCODE': 'no label', 'KIND': 'no label', });
lyr_sites_2.set('fieldLabels', {'id': 'no label', 'nom': 'no label', });
lyr_sites_2.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});